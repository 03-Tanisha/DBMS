
import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from mysql.connector import Error

# ---------- DATABASE CONNECTION ----------

def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Tanisha@03",
        database="student_db",
        port=3306
    )


# ---------- MAIN WINDOW ----------

root = tk.Tk()
root.title("Student Record Management System")
root.geometry("1000x650")
root.minsize(850, 550)

selected_student_id = None

title = tk.Label(
    root,
    text="STUDENT RECORD MANAGEMENT SYSTEM",
    font=("Arial", 18, "bold"),
    pady=15
)
title.pack()

# ---------- INPUT FORM ----------

form = tk.Frame(root, padx=20, pady=10)
form.pack(fill="x")

tk.Label(form, text="Student ID").grid(
    row=0, column=0, padx=8, pady=8, sticky="w"
)
id_entry = tk.Entry(form, width=25)
id_entry.grid(row=0, column=1, padx=8, pady=8)

tk.Label(form, text="Name").grid(
    row=0, column=2, padx=8, pady=8, sticky="w"
)
name_entry = tk.Entry(form, width=25)
name_entry.grid(row=0, column=3, padx=8, pady=8)

tk.Label(form, text="Email").grid(
    row=1, column=0, padx=8, pady=8, sticky="w"
)
email_entry = tk.Entry(form, width=25)
email_entry.grid(row=1, column=1, padx=8, pady=8)

tk.Label(form, text="Course").grid(
    row=1, column=2, padx=8, pady=8, sticky="w"
)
course_entry = tk.Entry(form, width=25)
course_entry.grid(row=1, column=3, padx=8, pady=8)

tk.Label(form, text="Semester").grid(
    row=2, column=0, padx=8, pady=8, sticky="w"
)
semester_entry = tk.Entry(form, width=25)
semester_entry.grid(row=2, column=1, padx=8, pady=8)


# ---------- HELPER FUNCTIONS ----------

def get_form_data():
    student_id = id_entry.get().strip()
    name = name_entry.get().strip()
    email = email_entry.get().strip()
    course = course_entry.get().strip()
    semester = semester_entry.get().strip()

    if not student_id or not name or not email or not course or not semester:
        messagebox.showwarning(
            "Missing Information", "Please fill in all fields."
        )
        return None

    try:
        student_id = int(student_id)
        semester = int(semester)

        if student_id <= 0:
            raise ValueError

        if semester < 1 or semester > 12:
            messagebox.showwarning(
                "Invalid Semester", "Semester must be between 1 and 12."
            )
            return None

    except ValueError:
        messagebox.showwarning(
            "Invalid Input",
            "Student ID must be a positive number and semester must be an integer."
        )
        return None

    if "@" not in email or "." not in email.split("@")[-1]:
        messagebox.showwarning(
            "Invalid Email", "Please enter a valid email address."
        )
        return None

    return student_id, name, email, course, semester


def clear_form():
    global selected_student_id
    for entry in (
        id_entry, name_entry, email_entry,
        course_entry, semester_entry
    ):
        entry.delete(0, tk.END)

    id_entry.config(state="normal")
    selected_student_id = None
    student_table.selection_remove(
        student_table.selection()
    )


# ---------- ADD STUDENT ----------

def add_student():
    data = get_form_data()
    if data is None:
        return

    connection = None
    try:
        connection = connect_db()
        cursor = connection.cursor()

        query = """
            INSERT INTO students
            (student_id, name, email, course, semester)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(query, data)
        connection.commit()

        messagebox.showinfo(
            "Success", "Student added successfully!"
        )
        clear_form()
        view_students()

    except Error as error:
        messagebox.showerror("Database Error", str(error))

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


# ---------- VIEW STUDENTS ----------

def view_students():
    connection = None
    try:
        connection = connect_db()
        cursor = connection.cursor()

        cursor.execute("""
            SELECT student_id, name, email, course, semester
            FROM students
            ORDER BY student_id
        """)
        records = cursor.fetchall()

        for item in student_table.get_children():
            student_table.delete(item)

        for record in records:
            student_table.insert("", tk.END, values=record)

    except Error as error:
        messagebox.showerror("Database Error", str(error))

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


# ---------- SELECT A STUDENT ----------

def select_student(event):
    global selected_student_id

    selected = student_table.selection()
    if not selected:
        return

    record = student_table.item(selected[0], "values")
    selected_student_id = int(record[0])

    clear_entries = (
        id_entry, name_entry, email_entry,
        course_entry, semester_entry
    )

    for entry, value in zip(clear_entries, record):
        entry.delete(0, tk.END)
        entry.insert(0, value)

    # Keep the original ID fixed during an update.
    id_entry.config(state="readonly")


# ---------- UPDATE STUDENT ----------

def update_student():
    global selected_student_id

    if selected_student_id is None:
        messagebox.showwarning(
            "Select Student",
            "Select a student from the table before updating."
        )
        return

    data = get_form_data()
    if data is None:
        return

    student_id, name, email, course, semester = data

    if student_id != selected_student_id:
        messagebox.showwarning(
            "Student ID",
            "The selected student's ID cannot be changed."
        )
        return

    connection = None
    try:
        connection = connect_db()
        cursor = connection.cursor()

        cursor.execute("""
            UPDATE students
            SET name = %s, email = %s, course = %s, semester = %s
            WHERE student_id = %s
        """, (name, email, course, semester, selected_student_id))

        connection.commit()

        if cursor.rowcount == 0:
            messagebox.showinfo(
                "No Changes", "No changes were made to this record."
            )
        else:
            messagebox.showinfo(
                "Success", "Student updated successfully!"
            )

        clear_form()
        view_students()

    except Error as error:
        messagebox.showerror("Database Error", str(error))

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


# ---------- DELETE STUDENT ----------

def delete_student():
    selected = student_table.selection()

    if not selected:
        messagebox.showwarning(
            "Select Student",
            "Select a student from the table before deleting."
        )
        return

    record = student_table.item(selected[0], "values")
    student_id = int(record[0])

    confirm = messagebox.askyesno(
        "Confirm Delete",
        f"Delete student ID {student_id}?"
    )

    if not confirm:
        return

    connection = None
    try:
        connection = connect_db()
        cursor = connection.cursor()

        cursor.execute(
            "DELETE FROM students WHERE student_id = %s",
            (student_id,)
        )
        connection.commit()

        messagebox.showinfo(
            "Success", "Student deleted successfully!"
        )
        clear_form()
        view_students()

    except Error as error:
        messagebox.showerror("Database Error", str(error))

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


# ---------- BUTTONS ----------

buttons = tk.Frame(root, pady=10)
buttons.pack()

tk.Button(
    buttons, text="Add Student",
    width=15, command=add_student
).grid(row=0, column=0, padx=5)

tk.Button(
    buttons, text="View / Refresh",
    width=15, command=view_students
).grid(row=0, column=1, padx=5)

tk.Button(
    buttons, text="Update Student",
    width=15, command=update_student
).grid(row=0, column=2, padx=5)

tk.Button(
    buttons, text="Delete Student",
    width=15, command=delete_student
).grid(row=0, column=3, padx=5)

tk.Button(
    buttons, text="Clear Form",
    width=15, command=clear_form
).grid(row=0, column=4, padx=5)


# ---------- STUDENT TABLE ----------

table_frame = tk.Frame(root, padx=20, pady=10)
table_frame.pack(fill="both", expand=True)

columns = (
    "student_id", "name", "email", "course", "semester"
)

student_table = ttk.Treeview(
    table_frame,
    columns=columns,
    show="headings",
    height=12
)

headings = {
    "student_id": "Student ID",
    "name": "Name",
    "email": "Email",
    "course": "Course",
    "semester": "Semester"
}

for column in columns:
    student_table.heading(column, text=headings[column])
    student_table.column(column, width=150, anchor="center")

scrollbar = ttk.Scrollbar(
    table_frame, orient="vertical",
    command=student_table.yview
)
student_table.configure(yscrollcommand=scrollbar.set)

student_table.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

student_table.bind("<<TreeviewSelect>>", select_student)


# ---------- START APPLICATION ----------

view_students()
root.mainloop()


