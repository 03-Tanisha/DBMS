# Student Record Management System

## Project overview
A simple desktop application built with Python, Tkinter, and MySQL. It stores student records in a MySQL database and supports adding, viewing, updating, and deleting records.

## Technologies
- Python 3
- Tkinter (GUI)
- MySQL Server
- `mysql-connector-python`

## Files
- `main.py` — application code (copy your working code here)
- `database.sql` — creates the database and table
- `Project_Report.docx` — project report template
- `screenshots/` — add screenshots captured from your running application

## Setup
1. Install Python and MySQL Server.
2. Run `database.sql` in MySQL Command Line Client or MySQL Workbench.
3. Install the connector in a terminal:
   `py -m pip install mysql-connector-python`
4. Open `main.py` and replace `YOUR_ROOT_PASSWORD` with your local MySQL root password. Do not share this password or submit it in screenshots.
5. Run the application:
   `py main.py`

## Database
Database: `student_db`

Table: `students`
- `student_id` — integer primary key
- `name` — required student name
- `email` — unique email
- `course` — required course
- `semester` — required semester number

## Features
- Add Student — SQL INSERT
- View / Refresh — SQL SELECT
- Update Student — SQL UPDATE
- Delete Student — SQL DELETE, after confirmation
- Basic validation for missing fields, numeric ID/semester, and email format

## Testing
Use a test record (not a real student's private information) and verify:
1. Add a record in the GUI.
2. View it in the GUI and run `SELECT * FROM students;` in MySQL.
3. Update the record and verify the changed values.
4. Delete the test record and verify it is absent from the query results.
5. Try invalid input and capture the validation message.

## Before submission
- Copy your final working `main.py` into this folder.
- Add genuine screenshots to `screenshots/`.
- Review the report and fill in your name, course, institution, and date.
- Do not include your MySQL password in the submitted files.
