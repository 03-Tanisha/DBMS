-- Student Record Management System
-- Database setup script

CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;

CREATE TABLE IF NOT EXISTS students (
    student_id INT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,
    course VARCHAR(50) NOT NULL,
    semester INT NOT NULL
);

-- Optional sample record for testing.
-- Comment this INSERT out if the email or ID already exists.
INSERT INTO students (student_id, name, email, course, semester)
VALUES (101, 'Ananya', 'ananya@example.com', 'BCA', 3);

-- Verify the table and stored records:
SHOW TABLES;
DESCRIBE students;
SELECT * FROM students;
